//================================//
// Main
//================================//
global.prefa = ['','!','.',',','🐤','🗿']
global.owner = ['601117630414']
global.cd = '300'; // 300 detik cooldown
global.linkOwner = "https://wa.me/601117630414"
//================================//
// Panel
//================================//
global.egg = "15"
global.nestid = "5"
global.loc = "1"
global.domain = "_"
global.apikey = "_"
global.capikey = "_"
//================================//
// Panel V2
//================================//
global.domain2 = "_"
global.apikey2 = "_"
global.capikey2 = "_"
//================================//
// Global Mess
//================================//
global.mess = {
 owner: '*You are not the owner*',
 premium: '*You are not premium*',
 group: '*This feature is for groups only*'
}