# DDoS Termux Tool by Joocode

## Alert
**WARNING:**  
Please **do not** misuse this tool for any illegal or malicious purposes.  
This script is for educational and testing purposes only.  
**DO NOT** sell, redistribute, or misuse this script in any form.  

**Feel free to modify** or **rename** the script, but always **give credit** to the original creator.

---

## Special Thanks To:

- **God (Tuhan)** – For everything.
- **Orang Tua (Support)** – For endless love and support.
- **Joocode (Developer)** – Creator and developer of this tool.
- **HamzDev (Husband/Suami)** – For constant encouragement and support.
- **Justinnwi (Best Friend)** – For being there when needed.
- **Miku Developer (Friends)** – For collaboration and inspiration.
- **AxpawX1 (Pemula)** – For early feedback and testing.
- **BenzDev (Best Friend)** – For continued support and friendship.
- **KaiziDev (Best Friend)** – For being a solid pillar in my journey.
- **DaffaDev (Friend)** – For always providing helpful insights.
- **Rapip (Pencinta Drakor)** – For love and support.
- **Alwaysqioo (Friend)** – For being an awesome friend.
- **All Buyers of Joo** – For your continued trust and support.

---

## Contact Me:

- WhatsApp: [+6281362675697](https://wa.me/+6281362675697)
- WhatsApp: [+6283141427943](https://wa.me/+6283141427943)
- Website: [JoozxDev](https://joozxdev.my.id)

---

## Installation & Usage

To install and run the DDoS Termux tool, follow these steps:

1. pkg update
2. pkg upgrade
3. pkg install python
4. pkg install git
5. git clone 6. https://github.com/Joodev65/Tools-DDOS-Joocode.git
7. cd Tools-DDOS-Joocode.git
8. python hammer.py
