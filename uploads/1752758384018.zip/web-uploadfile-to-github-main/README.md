# web-uploadfile-to-github
---------
# Note:
Apabila kalian ingin masang token githubnya di repo github kalian tapi gk bisa (token nya tiba2 kebanned mulu/tiba2 hangus) akalin aja dengan cara membagi 2 atau lebih tokennya

Contoh:
```javascript
const to = "ghp_aIAjuiswiNIsoiJaoa"
const ken = "IUhiahOisaiajoalaljKha"
const githubToken = `${to}${ken}`;
```
---------
# *EN*
### 📃 T&C
1. Not For Sale!
2. Don't forget give star this repo!
3. If you have problem [chat me](https://wa.me/6281312651566)

#  
 
# *ID*
### 📃 S&K
1. Tidak Untuk Dijual!!!
2. Jangan lupa kasih star di ni repo!
3. Jika kamu punya masalah [chat gwejh](https://wa.me/6281312651566)

---------
